package com.fundstart.dto;

import com.fundstart.model.Comment;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class CommentDTO {
    private UUID id;
    private String content;
    private UserDTO user;
    private LocalDateTime createdAt;

    public static CommentDTO fromComment(Comment comment) {
        CommentDTO dto = new CommentDTO();
        dto.setId(comment.getId());
        dto.setContent(comment.getContent());
        dto.setUser(UserDTO.fromUser(comment.getUser()));
        dto.setCreatedAt(comment.getCreatedAt());
        return dto;
    }
}