import { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { FiPlus, FiX, FiImage, FiCheck } from 'react-icons/fi'
import { motion } from 'framer-motion'
import { useProjects } from '../context/ProjectsContext'
import { useAuth } from '../context/AuthContext'

export default function CreateProject() {
  const navigate = useNavigate()
  const { createProject, categories } = useProjects()
  const { currentUser } = useAuth()
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    longDescription: '# Project Story\n\n## About\n\nTell us about your project...\n\n## The Problem\n\nWhat problem are you solving?\n\n## Your Solution\n\nHow does your project solve this problem?\n\n## How You\'ll Use The Funds\n\nBreak down how the funds will be used.',
    category: '',
    goal: '',
    daysToGo: '30',
    imageUrl: '',
    rewards: [
      {
        id: `reward-${Date.now()}`,
        title: '',
        description: '',
        amount: '',
        estimatedDelivery: ''
      }
    ]
  })
  
  const [errors, setErrors] = useState({})
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccessful, setIsSuccessful] = useState(false)

  // Redirect to login if not authenticated
  if (!currentUser) {
    navigate('/')
    return null
  }

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: value
    })
    
    // Clear error for this field
    if (errors[name]) {
      setErrors({
        ...errors,
        [name]: ''
      })
    }
  }
  
  const handleRewardChange = (index, field, value) => {
    const updatedRewards = [...formData.rewards]
    updatedRewards[index] = {
      ...updatedRewards[index],
      [field]: value
    }
    
    setFormData({
      ...formData,
      rewards: updatedRewards
    })
    
    // Clear error for this field
    if (errors[`rewards.${index}.${field}`]) {
      setErrors({
        ...errors,
        [`rewards.${index}.${field}`]: ''
      })
    }
  }
  
  const addReward = () => {
    setFormData({
      ...formData,
      rewards: [
        ...formData.rewards,
        {
          id: `reward-${Date.now()}`,
          title: '',
          description: '',
          amount: '',
          estimatedDelivery: ''
        }
      ]
    })
  }
  
  const removeReward = (index) => {
    if (formData.rewards.length === 1) return
    
    const updatedRewards = [...formData.rewards]
    updatedRewards.splice(index, 1)
    
    setFormData({
      ...formData,
      rewards: updatedRewards
    })
  }
  
  const validateForm = () => {
    const newErrors = {}
    
    // Validate required fields
    if (!formData.title) newErrors.title = 'Title is required'
    if (!formData.description) newErrors.description = 'Description is required'
    if (!formData.longDescription) newErrors.longDescription = 'Story is required'
    if (!formData.category) newErrors.category = 'Category is required'
    if (!formData.imageUrl) newErrors.imageUrl = 'Image URL is required'
    
    // Validate goal amount
    if (!formData.goal) {
      newErrors.goal = 'Funding goal is required'
    } else if (isNaN(formData.goal) || Number(formData.goal) <= 0) {
      newErrors.goal = 'Goal must be a positive number'
    }
    
    // Validate days
    if (!formData.daysToGo) {
      newErrors.daysToGo = 'Campaign duration is required'
    } else if (isNaN(formData.daysToGo) || Number(formData.daysToGo) <= 0) {
      newErrors.daysToGo = 'Duration must be a positive number'
    }
    
    // Validate rewards
    formData.rewards.forEach((reward, index) => {
      if (!reward.title) newErrors[`rewards.${index}.title`] = 'Title is required'
      if (!reward.description) newErrors[`rewards.${index}.description`] = 'Description is required'
      if (!reward.amount) {
        newErrors[`rewards.${index}.amount`] = 'Amount is required'
      } else if (isNaN(reward.amount) || Number(reward.amount) <= 0) {
        newErrors[`rewards.${index}.amount`] = 'Amount must be a positive number'
      }
      if (!reward.estimatedDelivery) newErrors[`rewards.${index}.estimatedDelivery`] = 'Delivery date is required'
    })
    
    setErrors(newErrors)
    return Object.keys(newErrors).length === 0
  }
  
  const handleSubmit = async (e) => {
    e.preventDefault()
    
    if (!validateForm()) return
    
    setIsSubmitting(true)
    
    try {
      // Format the data for submission
      const projectData = {
        title: formData.title,
        description: formData.description,
        longDescription: formData.longDescription,
        category: formData.category,
        goal: Number(formData.goal),
        daysLeft: Number(formData.daysToGo),
        imageUrl: formData.imageUrl,
        rewards: formData.rewards.map(reward => ({
          ...reward,
          amount: Number(reward.amount),
          claimed: 0,
          available: null
        })),
        creator: {
          name: currentUser.name,
          avatar: currentUser.avatar,
          bio: 'Project creator'
        }
      }
      
      const createdProject = createProject(projectData)
      
      setIsSuccessful(true)
      
      // Navigate to the created project after a delay
      setTimeout(() => {
        navigate(`/projects/${createdProject.id}`)
      }, 2000)
    } catch (error) {
      setErrors({
        submit: 'Error creating project. Please try again.'
      })
    } finally {
      setIsSubmitting(false)
    }
  }
  
  // Sample placeholder images to help users
  const sampleImages = [
    'https://images.pexels.com/photos/5202159/pexels-photo-5202159.jpeg',
    'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    'https://images.pexels.com/photos/6585601/pexels-photo-6585601.jpeg',
    'https://images.pexels.com/photos/6469/red-hands-woman-creative.jpg'
  ]

  return (
    <div className="pt-24 pb-16">
      <div className="container max-w-4xl">
        <h1 className="text-3xl md:text-4xl font-display font-bold mb-6">
          Create Your Project
        </h1>
        <p className="text-gray-600 mb-8">
          Share your idea with the world and find the support to make it happen.
        </p>
        
        {isSuccessful ? (
          <motion.div 
            className="bg-green-50 border border-green-200 rounded-lg p-8 text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
          >
            <div className="w-16 h-16 bg-green-100 text-green-500 rounded-full flex items-center justify-center mx-auto mb-4">
              <FiCheck size={32} />
            </div>
            <h2 className="text-2xl font-display font-semibold mb-2">Project Created Successfully!</h2>
            <p className="text-gray-600 mb-4">
              Your project has been created and is now ready for backers.
            </p>
            <p className="text-sm text-gray-500">
              Redirecting you to your project page...
            </p>
          </motion.div>
        ) : (
          <form onSubmit={handleSubmit} className="space-y-8">
            {errors.submit && (
              <div className="p-4 bg-red-50 text-red-700 rounded-lg">
                {errors.submit}
              </div>
            )}
            
            {/* Basic info section */}
            <section className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-display font-semibold mb-6">Basic Information</h2>
              
              <div className="space-y-6">
                <div>
                  <label htmlFor="title" className="label">Project Title</label>
                  <input
                    id="title"
                    name="title"
                    type="text"
                    value={formData.title}
                    onChange={handleChange}
                    className={`input ${errors.title ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                    placeholder="e.g., EcoFresh: Sustainable Food Storage"
                  />
                  {errors.title && <p className="mt-1 text-red-500 text-sm">{errors.title}</p>}
                </div>
                
                <div>
                  <label htmlFor="description" className="label">Short Description</label>
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleChange}
                    className={`input h-24 ${errors.description ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                    placeholder="A brief, compelling description of your project (limit: 160 characters)"
                    maxLength={160}
                  />
                  {errors.description && <p className="mt-1 text-red-500 text-sm">{errors.description}</p>}
                  <p className="mt-1 text-sm text-gray-500 flex justify-end">{formData.description.length}/160</p>
                </div>
                
                <div>
                  <label htmlFor="category" className="label">Category</label>
                  <select
                    id="category"
                    name="category"
                    value={formData.category}
                    onChange={handleChange}
                    className={`input ${errors.category ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                  >
                    <option value="">Select a category</option>
                    {categories.map(category => (
                      <option key={category} value={category}>{category}</option>
                    ))}
                  </select>
                  {errors.category && <p className="mt-1 text-red-500 text-sm">{errors.category}</p>}
                </div>
              </div>
            </section>
            
            {/* Funding section */}
            <section className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-display font-semibold mb-6">Funding</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="goal" className="label">Funding Goal ($)</label>
                  <input
                    id="goal"
                    name="goal"
                    type="number"
                    value={formData.goal}
                    onChange={handleChange}
                    className={`input ${errors.goal ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                    placeholder="e.g., 10000"
                    min="1"
                  />
                  {errors.goal && <p className="mt-1 text-red-500 text-sm">{errors.goal}</p>}
                </div>
                
                <div>
                  <label htmlFor="daysToGo" className="label">Campaign Duration (days)</label>
                  <input
                    id="daysToGo"
                    name="daysToGo"
                    type="number"
                    value={formData.daysToGo}
                    onChange={handleChange}
                    className={`input ${errors.daysToGo ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                    placeholder="e.g., 30"
                    min="1"
                    max="60"
                  />
                  {errors.daysToGo && <p className="mt-1 text-red-500 text-sm">{errors.daysToGo}</p>}
                </div>
              </div>
            </section>
            
            {/* Project media section */}
            <section className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-display font-semibold mb-6">Project Media</h2>
              
              <div>
                <label htmlFor="imageUrl" className="label">Main Project Image URL</label>
                <input
                  id="imageUrl"
                  name="imageUrl"
                  type="url"
                  value={formData.imageUrl}
                  onChange={handleChange}
                  className={`input ${errors.imageUrl ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                  placeholder="e.g., https://images.pexels.com/photos/..."
                />
                {errors.imageUrl && <p className="mt-1 text-red-500 text-sm">{errors.imageUrl}</p>}
                
                {/* Image preview */}
                {formData.imageUrl && (
                  <div className="mt-3 mb-6">
                    <p className="text-sm text-gray-500 mb-2">Preview:</p>
                    <img 
                      src={formData.imageUrl} 
                      alt="Project preview" 
                      className="w-full max-h-80 object-cover rounded-lg"
                      onError={(e) => {
                        e.target.onerror = null
                        e.target.src = 'https://via.placeholder.com/800x450?text=Invalid+Image+URL'
                      }}
                    />
                  </div>
                )}
                
                {/* Sample images */}
                <div className="mt-4">
                  <p className="text-sm text-gray-500 mb-2">Sample images you can use:</p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {sampleImages.map((imgUrl, idx) => (
                      <button
                        key={idx}
                        type="button"
                        className="bg-gray-100 rounded-lg overflow-hidden hover:ring-2 hover:ring-primary-300 transition-all"
                        onClick={() => {
                          setFormData({
                            ...formData,
                            imageUrl: imgUrl
                          })
                          if (errors.imageUrl) {
                            setErrors({
                              ...errors,
                              imageUrl: ''
                            })
                          }
                        }}
                      >
                        <img 
                          src={imgUrl} 
                          alt={`Sample ${idx + 1}`} 
                          className="w-full h-24 object-cover"
                        />
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            </section>
            
            {/* Project story section */}
            <section className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-display font-semibold mb-6">Project Story</h2>
              
              <div>
                <label htmlFor="longDescription" className="label">
                  Project Story (Markdown supported)
                </label>
                <textarea
                  id="longDescription"
                  name="longDescription"
                  value={formData.longDescription}
                  onChange={handleChange}
                  className={`input h-96 font-mono text-sm ${errors.longDescription ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                />
                {errors.longDescription && <p className="mt-1 text-red-500 text-sm">{errors.longDescription}</p>}
                <p className="mt-1 text-sm text-gray-500">
                  Use Markdown formatting: # for headings, ** for bold, * for italic, etc.
                </p>
              </div>
            </section>
            
            {/* Rewards section */}
            <section className="bg-white p-8 rounded-xl shadow-sm border border-gray-100">
              <h2 className="text-xl font-display font-semibold mb-6">Rewards</h2>
              
              <div className="space-y-8">
                {formData.rewards.map((reward, index) => (
                  <div 
                    key={reward.id} 
                    className="p-6 bg-gray-50 rounded-lg relative"
                  >
                    {formData.rewards.length > 1 && (
                      <button
                        type="button"
                        className="absolute right-4 top-4 text-gray-400 hover:text-red-500"
                        onClick={() => removeReward(index)}
                      >
                        <FiX size={20} />
                      </button>
                    )}
                    
                    <h3 className="text-lg font-medium mb-4">Reward {index + 1}</h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <label htmlFor={`reward-title-${index}`} className="label">Title</label>
                        <input
                          id={`reward-title-${index}`}
                          type="text"
                          value={reward.title}
                          onChange={(e) => handleRewardChange(index, 'title', e.target.value)}
                          className={`input ${errors[`rewards.${index}.title`] ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                          placeholder="e.g., Early Bird Special"
                        />
                        {errors[`rewards.${index}.title`] && <p className="mt-1 text-red-500 text-sm">{errors[`rewards.${index}.title`]}</p>}
                      </div>
                      
                      <div>
                        <label htmlFor={`reward-amount-${index}`} className="label">Amount ($)</label>
                        <input
                          id={`reward-amount-${index}`}
                          type="number"
                          value={reward.amount}
                          onChange={(e) => handleRewardChange(index, 'amount', e.target.value)}
                          className={`input ${errors[`rewards.${index}.amount`] ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                          placeholder="e.g., 25"
                          min="1"
                        />
                        {errors[`rewards.${index}.amount`] && <p className="mt-1 text-red-500 text-sm">{errors[`rewards.${index}.amount`]}</p>}
                      </div>
                    </div>
                    
                    <div className="mt-4">
                      <label htmlFor={`reward-description-${index}`} className="label">Description</label>
                      <textarea
                        id={`reward-description-${index}`}
                        value={reward.description}
                        onChange={(e) => handleRewardChange(index, 'description', e.target.value)}
                        className={`input h-24 ${errors[`rewards.${index}.description`] ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                        placeholder="Describe what backers will receive for this reward"
                      />
                      {errors[`rewards.${index}.description`] && <p className="mt-1 text-red-500 text-sm">{errors[`rewards.${index}.description`]}</p>}
                    </div>
                    
                    <div className="mt-4">
                      <label htmlFor={`reward-delivery-${index}`} className="label">Estimated Delivery</label>
                      <input
                        id={`reward-delivery-${index}`}
                        type="text"
                        value={reward.estimatedDelivery}
                        onChange={(e) => handleRewardChange(index, 'estimatedDelivery', e.target.value)}
                        className={`input ${errors[`rewards.${index}.estimatedDelivery`] ? 'border-red-300 focus:ring-red-500 focus:border-red-500' : ''}`}
                        placeholder="e.g., March 2024"
                      />
                      {errors[`rewards.${index}.estimatedDelivery`] && <p className="mt-1 text-red-500 text-sm">{errors[`rewards.${index}.estimatedDelivery`]}</p>}
                    </div>
                  </div>
                ))}
                
                <button
                  type="button"
                  onClick={addReward}
                  className="flex items-center justify-center w-full p-4 border-2 border-dashed border-gray-300 rounded-lg text-gray-500 hover:text-primary-500 hover:border-primary-300 transition-colors"
                >
                  <FiPlus className="mr-2" />
                  Add Another Reward
                </button>
              </div>
            </section>
            
            <div className="flex justify-between items-center pt-6">
              <button
                type="button"
                onClick={() => navigate('/')}
                className="btn btn-outline"
              >
                Cancel
              </button>
              
              <button
                type="submit"
                className="btn btn-primary btn-lg"
                disabled={isSubmitting}
              >
                {isSubmitting ? (
                  <span className="flex items-center">
                    <svg className="animate-spin -ml-1 mr-2 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                      <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                      <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    Creating Project...
                  </span>
                ) : (
                  'Create Project'
                )}
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}