package com.fundstart.controller;

import com.fundstart.dto.ProjectDTO;
import com.fundstart.model.Project;
import com.fundstart.service.ProjectService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.UUID;

@RestController
@RequestMapping("/projects")
@RequiredArgsConstructor
public class ProjectController {
    private final ProjectService projectService;

    @GetMapping
    public ResponseEntity<List<ProjectDTO>> getAllProjects(
            @RequestParam(required = false) String category,
            @RequestParam(defaultValue = "trending") String sort) {
        return ResponseEntity.ok(projectService.getAllProjects(category, sort));
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProjectDTO> getProject(@PathVariable UUID id) {
        return ResponseEntity.ok(projectService.getProject(id));
    }

    @PostMapping
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ProjectDTO> createProject(@Valid @RequestBody ProjectDTO projectDTO) {
        return ResponseEntity.ok(projectService.createProject(projectDTO));
    }

    @PostMapping("/{id}/pledge")
    @PreAuthorize("isAuthenticated()")
    public ResponseEntity<ProjectDTO> pledgeToProject(
            @PathVariable UUID id,
            @RequestParam UUID rewardId,
            @RequestParam Double amount) {
        return ResponseEntity.ok(projectService.pledgeToProject(id, rewardId, amount));
    }
}