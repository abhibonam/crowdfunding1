import { useState, useEffect } from 'react'
import { Link, useLocation } from 'react-router-dom'
import { FiSearch, FiMenu, FiX } from 'react-icons/fi'
import { motion, AnimatePresence } from 'framer-motion'
import { useAuth } from '../../context/AuthContext'

export default function Header({ openAuthModal }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const { currentUser, logout } = useAuth()
  const location = useLocation()

  // Handle scroll event to change header background
  useEffect(() => {
    const handleScroll = () => {
      const isScrolled = window.scrollY > 10
      if (isScrolled !== scrolled) {
        setScrolled(isScrolled)
      }
    }

    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [scrolled])

  // Close menu when location changes
  useEffect(() => {
    setIsMenuOpen(false)
  }, [location])

  const toggleMenu = () => setIsMenuOpen(!isMenuOpen)

  const handleLogout = () => {
    logout()
    setIsMenuOpen(false)
  }

  return (
    <header 
      className={`fixed w-full z-50 transition-all duration-300 ${
        scrolled ? 'bg-white shadow-md py-3' : 'bg-transparent py-5'
      }`}
    >
      <div className="container flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center">
          <span className="text-2xl font-display font-bold text-primary-600">
            Fund<span className="text-accent-500">Start</span>
          </span>
        </Link>

        {/* Desktop Navigation */}
        <nav className="hidden md:flex items-center space-x-8">
          <Link 
            to="/" 
            className={`text-sm font-medium hover:text-primary-500 transition-colors ${
              location.pathname === '/' ? 'text-primary-500' : 'text-gray-700'
            }`}
          >
            Home
          </Link>
          <Link 
            to="/discover" 
            className={`text-sm font-medium hover:text-primary-500 transition-colors ${
              location.pathname === '/discover' ? 'text-primary-500' : 'text-gray-700'
            }`}
          >
            Discover
          </Link>
          <Link 
            to="/create" 
            className={`text-sm font-medium hover:text-primary-500 transition-colors ${
              location.pathname === '/create' ? 'text-primary-500' : 'text-gray-700'
            }`}
          >
            Start a Project
          </Link>
        </nav>

        {/* Desktop Right Section */}
        <div className="hidden md:flex items-center space-x-6">
          <div className="relative">
            <input
              type="text"
              placeholder="Search projects..."
              className="bg-gray-100 px-4 py-2 pr-10 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 w-48"
            />
            <FiSearch className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
          </div>

          {currentUser ? (
            <div className="flex items-center space-x-4">
              <div className="flex items-center">
                <img 
                  src={currentUser.avatar} 
                  alt={currentUser.name}
                  className="w-8 h-8 rounded-full border-2 border-primary-300"
                />
                <span className="ml-2 text-sm font-medium">{currentUser.name}</span>
              </div>
              <button 
                onClick={handleLogout}
                className="text-sm font-medium text-gray-700 hover:text-primary-500 transition-colors"
              >
                Log out
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-4">
              <button 
                onClick={() => openAuthModal('login')}
                className="text-sm font-medium text-gray-700 hover:text-primary-500 transition-colors"
              >
                Log in
              </button>
              <button 
                onClick={() => openAuthModal('signup')}
                className="btn btn-primary btn-sm"
              >
                Sign up
              </button>
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden text-gray-700 p-2"
          onClick={toggleMenu}
          aria-label="Toggle menu"
        >
          {isMenuOpen ? <FiX size={24} /> : <FiMenu size={24} />}
        </button>

        {/* Mobile Menu */}
        <AnimatePresence>
          {isMenuOpen && (
            <motion.div
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              transition={{ duration: 0.2 }}
              className="absolute top-full left-0 right-0 bg-white shadow-lg md:hidden z-50"
            >
              <div className="container py-4">
                <div className="flex justify-center mb-4">
                  <div className="relative w-full max-w-sm">
                    <input
                      type="text"
                      placeholder="Search projects..."
                      className="bg-gray-100 px-4 py-2 pr-10 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-primary-300 w-full"
                    />
                    <FiSearch className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
                  </div>
                </div>

                <nav className="flex flex-col space-y-3">
                  <Link 
                    to="/" 
                    className={`text-base py-2 px-4 rounded-lg ${
                      location.pathname === '/' ? 'bg-primary-50 text-primary-500' : 'text-gray-700'
                    }`}
                  >
                    Home
                  </Link>
                  <Link 
                    to="/discover" 
                    className={`text-base py-2 px-4 rounded-lg ${
                      location.pathname === '/discover' ? 'bg-primary-50 text-primary-500' : 'text-gray-700'
                    }`}
                  >
                    Discover
                  </Link>
                  <Link 
                    to="/create" 
                    className={`text-base py-2 px-4 rounded-lg ${
                      location.pathname === '/create' ? 'bg-primary-50 text-primary-500' : 'text-gray-700'
                    }`}
                  >
                    Start a Project
                  </Link>
                </nav>

                <div className="mt-4 pt-4 border-t border-gray-200">
                  {currentUser ? (
                    <div className="flex flex-col space-y-3">
                      <div className="flex items-center px-4">
                        <img 
                          src={currentUser.avatar} 
                          alt={currentUser.name}
                          className="w-8 h-8 rounded-full border-2 border-primary-300"
                        />
                        <span className="ml-2 font-medium">{currentUser.name}</span>
                      </div>
                      <button 
                        onClick={handleLogout}
                        className="text-left px-4 py-2 text-red-600 font-medium"
                      >
                        Log out
                      </button>
                    </div>
                  ) : (
                    <div className="flex flex-col space-y-3 px-4">
                      <button 
                        onClick={() => {
                          openAuthModal('login')
                          setIsMenuOpen(false)
                        }}
                        className="btn btn-outline w-full"
                      >
                        Log in
                      </button>
                      <button 
                        onClick={() => {
                          openAuthModal('signup')
                          setIsMenuOpen(false)
                        }}
                        className="btn btn-primary w-full"
                      >
                        Sign up
                      </button>
                    </div>
                  )}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </header>
  )
}