import { useState, useEffect } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { FiClock, FiUsers, FiArrowLeft, FiCheck } from 'react-icons/fi'
import { motion } from 'framer-motion'
import ReactMarkdown from 'react-markdown'
import { useProjects } from '../context/ProjectsContext'
import { useAuth } from '../context/AuthContext'

export default function ProjectDetails({ openAuthModal }) {
  const { id } = useParams()
  const navigate = useNavigate()
  const { getProject, backProject } = useProjects()
  const { currentUser } = useAuth()
  
  const [project, setProject] = useState(null)
  const [loading, setLoading] = useState(true)
  const [selectedReward, setSelectedReward] = useState(null)
  const [customAmount, setCustomAmount] = useState('')
  const [pledgeAmount, setPledgeAmount] = useState('')
  const [pledgeSuccess, setPledgeSuccess] = useState(false)
  const [activeSectionId, setActiveSectionId] = useState('story')

  useEffect(() => {
    const loadProject = () => {
      const projectData = getProject(id)
      if (projectData) {
        setProject(projectData)
      } else {
        navigate('/not-found')
      }
      setLoading(false)
    }
    
    loadProject()
  }, [id, getProject, navigate])

  useEffect(() => {
    window.scrollTo(0, 0)
  }, [])

  if (loading) {
    return (
      <div className="pt-24 pb-16">
        <div className="container">
          <div className="animate-pulse">
            <div className="h-96 bg-gray-200 rounded-lg mb-8"></div>
            <div className="h-10 bg-gray-200 rounded w-3/4 mb-4"></div>
            <div className="h-6 bg-gray-200 rounded w-1/2 mb-8"></div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div className="col-span-2">
                <div className="h-4 bg-gray-200 rounded mb-3"></div>
                <div className="h-4 bg-gray-200 rounded mb-3"></div>
                <div className="h-4 bg-gray-200 rounded mb-3"></div>
                <div className="h-4 bg-gray-200 rounded mb-3"></div>
              </div>
              <div className="h-64 bg-gray-200 rounded"></div>
            </div>
          </div>
        </div>
      </div>
    )
  }

  if (!project) return null

  const percentFunded = Math.min(Math.round((project.funded / project.goal) * 100), 100)
  const isFullyFunded = percentFunded >= 100

  const handleBackProject = (reward = null) => {
    let amount = reward ? reward.amount : parseInt(customAmount, 10)
    
    if (!amount || amount < 1) {
      alert('Please enter a valid amount')
      return
    }
    
    if (!currentUser) {
      openAuthModal('login')
      return
    }
    
    backProject(project.id, amount, currentUser.id, reward)
    
    // Update local state
    setProject(getProject(project.id))
    setPledgeSuccess(true)
    setSelectedReward(null)
    setCustomAmount('')
    setPledgeAmount('')
    
    // Reset success message after a delay
    setTimeout(() => {
      setPledgeSuccess(false)
    }, 3000)
  }

  const selectReward = (reward) => {
    setSelectedReward(reward)
    setPledgeAmount(reward.amount.toString())
    window.scrollTo({
      top: document.getElementById('back-section').offsetTop - 100,
      behavior: 'smooth'
    })
  }

  return (
    <div className="pt-24 pb-16">
      <div className="container">
        {/* Back button */}
        <button 
          onClick={() => navigate(-1)}
          className="flex items-center text-gray-600 hover:text-primary-500 mb-6 transition-colors"
        >
          <FiArrowLeft className="mr-2" />
          Back to projects
        </button>
        
        {/* Project header */}
        <div className="mb-10">
          <h1 className="text-3xl md:text-4xl font-display font-bold mb-4">
            {project.title}
          </h1>
          <p className="text-lg text-gray-600 mb-6">
            {project.description}
          </p>
          
          <div className="flex items-center space-x-4">
            <div className="flex items-center">
              <img 
                src={project.creator.avatar} 
                alt={project.creator.name}
                className="w-10 h-10 rounded-full mr-3 border-2 border-primary-100"
              />
              <div>
                <p className="text-sm font-medium">By {project.creator.name}</p>
                <p className="text-xs text-gray-500">{project.creator.bio}</p>
              </div>
            </div>
            
            <span className="text-xs font-medium text-white px-3 py-1 rounded-full bg-secondary-500">
              {project.category}
            </span>
          </div>
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main content - left 2/3 */}
          <div className="lg:col-span-2">
            <div className="rounded-xl overflow-hidden mb-8">
              <img 
                src={project.imageUrl} 
                alt={project.title}
                className="w-full h-auto object-cover"
              />
            </div>
            
            {/* Tabs navigation */}
            <nav className="flex border-b border-gray-200 mb-8">
              <button
                className={`px-4 py-3 font-medium text-sm mr-4 border-b-2 transition-colors ${
                  activeSectionId === 'story' 
                  ? 'border-primary-500 text-primary-500' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveSectionId('story')}
              >
                Story
              </button>
              <button
                className={`px-4 py-3 font-medium text-sm mr-4 border-b-2 transition-colors ${
                  activeSectionId === 'updates' 
                  ? 'border-primary-500 text-primary-500' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveSectionId('updates')}
              >
                Updates {project.updates.length > 0 && `(${project.updates.length})`}
              </button>
              <button
                className={`px-4 py-3 font-medium text-sm border-b-2 transition-colors ${
                  activeSectionId === 'comments' 
                  ? 'border-primary-500 text-primary-500' 
                  : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
                onClick={() => setActiveSectionId('comments')}
              >
                Comments {project.comments.length > 0 && `(${project.comments.length})`}
              </button>
            </nav>
            
            {/* Tab content */}
            <div className="prose prose-lg max-w-none">
              {activeSectionId === 'story' && (
                <ReactMarkdown>{project.longDescription}</ReactMarkdown>
              )}
              
              {activeSectionId === 'updates' && (
                <div>
                  <h2 className="text-2xl font-display font-semibold mb-6">Project Updates</h2>
                  
                  {project.updates.length === 0 ? (
                    <div className="p-6 bg-gray-50 rounded-lg text-center">
                      <p className="text-gray-500">No updates yet.</p>
                    </div>
                  ) : (
                    <div className="space-y-8">
                      {project.updates.map(update => (
                        <div key={update.id} className="p-6 bg-gray-50 rounded-lg">
                          <div className="flex justify-between items-center mb-4">
                            <h3 className="text-xl font-semibold">{update.title}</h3>
                            <span className="text-sm text-gray-500">{update.date}</span>
                          </div>
                          <p className="text-gray-700">{update.content}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
              
              {activeSectionId === 'comments' && (
                <div>
                  <h2 className="text-2xl font-display font-semibold mb-6">Comments</h2>
                  
                  {project.comments.length === 0 ? (
                    <div className="p-6 bg-gray-50 rounded-lg text-center">
                      <p className="text-gray-500">No comments yet. Be the first to comment!</p>
                    </div>
                  ) : (
                    <div className="space-y-6">
                      {project.comments.map(comment => (
                        <div key={comment.id} className="flex space-x-4">
                          <img 
                            src={comment.user.avatar} 
                            alt={comment.user.name}
                            className="w-10 h-10 rounded-full flex-shrink-0"
                          />
                          <div className="flex-grow">
                            <div className="flex justify-between items-center mb-2">
                              <h4 className="font-medium">{comment.user.name}</h4>
                              <span className="text-sm text-gray-500">{comment.date}</span>
                            </div>
                            <p className="text-gray-700">{comment.content}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  
                  {currentUser ? (
                    <div className="mt-8 p-6 bg-gray-50 rounded-lg">
                      <h3 className="text-lg font-medium mb-4">Leave a comment</h3>
                      <textarea 
                        className="input min-h-32 mb-4" 
                        placeholder="Write your comment here..." 
                      />
                      <button className="btn btn-primary">Post Comment</button>
                    </div>
                  ) : (
                    <div className="mt-8 p-6 bg-gray-50 rounded-lg text-center">
                      <p className="mb-4 text-gray-700">You need to be logged in to comment.</p>
                      <button 
                        onClick={() => openAuthModal('login')}
                        className="btn btn-primary"
                      >
                        Log in to comment
                      </button>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
          
          {/* Sidebar - right 1/3 */}
          <div className="space-y-8">
            {/* Funding progress */}
            <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100">
              <div className="mb-4">
                <div className="w-full bg-gray-200 h-3 rounded-full">
                  <div 
                    className={`h-3 rounded-full ${isFullyFunded ? 'bg-success-500' : 'bg-primary-500'}`}
                    style={{ width: `${percentFunded}%` }}
                  />
                </div>
              </div>
              
              <div className="mb-6">
                <h3 className="text-3xl font-display font-bold mb-1">
                  ${project.funded.toLocaleString()}
                </h3>
                <p className="text-gray-500 text-sm">
                  pledged of ${project.goal.toLocaleString()} goal
                </p>
              </div>
              
              <div className="grid grid-cols-2 gap-6 mb-6">
                <div>
                  <h4 className="text-2xl font-display font-bold mb-1">
                    {project.backers.toLocaleString()}
                  </h4>
                  <p className="text-gray-500 text-sm">backers</p>
                </div>
                <div>
                  <h4 className="text-2xl font-display font-bold mb-1">
                    {project.daysLeft}
                  </h4>
                  <p className="text-gray-500 text-sm">days to go</p>
                </div>
              </div>
              
              <motion.button 
                id="back-section"
                className="btn btn-primary w-full mb-4"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                onClick={() => setSelectedReward({ id: 'custom', title: 'Custom Amount' })}
              >
                Back this project
              </motion.button>
              
              <div className="flex items-center text-sm text-gray-500 justify-center">
                <FiClock className="mr-1" />
                <span>Campaign ends {project.daysLeft} days from now</span>
              </div>
            </div>
            
            {/* Pledge form (shows when a reward is selected) */}
            {selectedReward && (
              <motion.div 
                className="bg-white p-6 rounded-xl shadow-sm border border-primary-200"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
              >
                <h3 className="text-lg font-semibold mb-4">
                  {selectedReward.id === 'custom' ? 'Support this project' : `Back: ${selectedReward.title}`}
                </h3>
                
                <div className="mb-4">
                  <label htmlFor="pledge-amount" className="label">Pledge amount</label>
                  <div className="relative">
                    <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">$</span>
                    <input
                      id="pledge-amount"
                      type="number"
                      min="1"
                      value={selectedReward.id === 'custom' ? customAmount : pledgeAmount}
                      onChange={(e) => {
                        if (selectedReward.id === 'custom') {
                          setCustomAmount(e.target.value)
                        } else {
                          setPledgeAmount(e.target.value)
                        }
                      }}
                      className="input pl-8"
                      placeholder="Enter amount"
                    />
                  </div>
                  {selectedReward.id !== 'custom' && (
                    <p className="text-xs text-gray-500 mt-1">
                      Minimum pledge: ${selectedReward.amount}
                    </p>
                  )}
                </div>
                
                {pledgeSuccess ? (
                  <div className="p-4 bg-green-50 text-green-700 rounded-lg flex items-center mb-4">
                    <FiCheck className="mr-2" />
                    Thank you for your support!
                  </div>
                ) : (
                  <div className="flex space-x-3">
                    <button 
                      className="btn btn-primary flex-grow"
                      onClick={() => handleBackProject(selectedReward.id === 'custom' ? null : selectedReward)}
                    >
                      Pledge
                    </button>
                    <button 
                      className="btn btn-outline"
                      onClick={() => {
                        setSelectedReward(null)
                        setCustomAmount('')
                        setPledgeAmount('')
                      }}
                    >
                      Cancel
                    </button>
                  </div>
                )}
              </motion.div>
            )}
            
            {/* Reward tiers */}
            <div>
              <h3 className="text-xl font-display font-semibold mb-4">Select a Reward</h3>
              
              <div className="space-y-4">
                {project.rewards.map(reward => {
                  const isClaimed = reward.available !== null && reward.claimed >= reward.available
                  
                  return (
                    <motion.div 
                      key={reward.id}
                      className={`border rounded-xl p-5 transition-all ${
                        isClaimed 
                          ? 'bg-gray-50 border-gray-200' 
                          : 'bg-white border-gray-200 hover:border-primary-300 hover:shadow-md'
                      }`}
                      whileHover={!isClaimed ? { scale: 1.02 } : {}}
                    >
                      <div className="flex justify-between items-start mb-3">
                        <h4 className="font-display font-semibold">
                          {reward.title}
                        </h4>
                        <span className="font-display font-bold text-lg">
                          ${reward.amount}
                        </span>
                      </div>
                      
                      <p className="text-gray-600 text-sm mb-4">
                        {reward.description}
                      </p>
                      
                      <div className="flex flex-wrap justify-between items-center text-sm text-gray-500">
                        <div className="mb-2 sm:mb-0">
                          <span className="inline-block mr-4">
                            <FiUsers className="inline mr-1" />
                            {reward.claimed} backers
                          </span>
                          <span>
                            <FiClock className="inline mr-1" />
                            Est. delivery: {reward.estimatedDelivery}
                          </span>
                        </div>
                        
                        {reward.available !== null && (
                          <span className={isClaimed ? 'text-red-500 font-medium' : 'text-green-600'}>
                            {isClaimed ? 'All gone!' : `${reward.available - reward.claimed} left`}
                          </span>
                        )}
                      </div>
                      
                      {!isClaimed && (
                        <button 
                          onClick={() => selectReward(reward)}
                          className="mt-4 w-full btn btn-outline text-primary-500 hover:bg-primary-50"
                        >
                          Select this reward
                        </button>
                      )}
                    </motion.div>
                  )
                })}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}