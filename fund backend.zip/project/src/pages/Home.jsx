import { useState } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { useProjects } from '../context/ProjectsContext'
import { useAuth } from '../context/AuthContext'
import ProjectCard from '../components/projects/ProjectCard'
import CategoryButton from '../components/ui/CategoryButton'

export default function Home({ openAuthModal }) {
  const { featuredProjects, categories, loading } = useProjects()
  const { currentUser } = useAuth()
  const [selectedCategory, setSelectedCategory] = useState('all')

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  }

  return (
    <div className="pt-20">
      {/* Hero section */}
      <section className="relative bg-gradient-to-br from-primary-600 to-secondary-700 text-white py-20 md:py-32">
        <div className="absolute inset-0 overflow-hidden">
          <svg 
            className="absolute bottom-0 left-0 transform translate-y-1/2" 
            width="600" 
            height="600" 
            viewBox="0 0 600 600"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle cx="300" cy="300" r="300" fill="white" fillOpacity="0.05" />
          </svg>
          <svg 
            className="absolute top-0 right-0 transform -translate-y-1/3" 
            width="400" 
            height="400" 
            viewBox="0 0 400 400"
            fill="none"
            xmlns="http://www.w3.org/2000/svg"
          >
            <circle cx="200" cy="200" r="200" fill="white" fillOpacity="0.05" />
          </svg>
        </div>
        
        <div className="container relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <motion.h1 
              className="text-4xl md:text-5xl lg:text-6xl font-display font-bold mb-6"
              initial={{ opacity: 0, y: -20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
            >
              Bring your ideas to life
            </motion.h1>
            <motion.p 
              className="text-lg md:text-xl opacity-90 mb-8"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              FundStart helps creators find the resources and support they need to make their ideas a reality.
            </motion.p>
            <motion.div 
              className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-4"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <Link to="/discover" className="btn btn-accent btn-lg">
                Explore Projects
              </Link>
              
              {currentUser ? (
                <Link to="/create" className="btn bg-white text-primary-600 hover:bg-gray-100 btn-lg">
                  Start a Project
                </Link>
              ) : (
                <button 
                  onClick={() => openAuthModal('signup')} 
                  className="btn bg-white text-primary-600 hover:bg-gray-100 btn-lg"
                >
                  Start a Project
                </button>
              )}
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured projects section */}
      <section className="py-16 bg-white">
        <div className="container">
          <div className="flex justify-between items-center mb-12">
            <h2 className="text-3xl font-display font-bold">Featured Projects</h2>
            <Link to="/discover" className="text-primary-500 font-medium hover:text-primary-600">
              View all →
            </Link>
          </div>

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              {[...Array(3)].map((_, index) => (
                <div key={index} className="bg-gray-100 animate-pulse rounded-xl h-96"></div>
              ))}
            </div>
          ) : (
            <motion.div 
              className="grid grid-cols-1 md:grid-cols-3 gap-8"
              variants={containerVariants}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-100px" }}
            >
              {featuredProjects.map(project => (
                <motion.div key={project.id} variants={itemVariants}>
                  <ProjectCard project={project} />
                </motion.div>
              ))}
            </motion.div>
          )}
        </div>
      </section>

      {/* Categories section */}
      <section className="py-16 bg-gray-50">
        <div className="container">
          <h2 className="text-3xl font-display font-bold mb-12 text-center">
            Discover by Category
          </h2>

          <div className="flex flex-wrap justify-center gap-4 mb-12">
            <CategoryButton
              category="all"
              label="All Projects"
              selected={selectedCategory === 'all'}
              onClick={() => setSelectedCategory('all')}
            />
            
            {categories.map(category => (
              <CategoryButton
                key={category}
                category={category}
                label={category}
                selected={selectedCategory === category}
                onClick={() => setSelectedCategory(category)}
              />
            ))}
          </div>

          <div className="text-center">
            <Link to="/discover" className="btn btn-primary">
              Browse All Categories
            </Link>
          </div>
        </div>
      </section>

      {/* How it works section */}
      <section className="py-16 bg-white">
        <div className="container">
          <h2 className="text-3xl font-display font-bold mb-16 text-center">
            How It Works
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <div className="w-20 h-20 bg-primary-100 text-primary-600 flex items-center justify-center rounded-full text-2xl font-bold mx-auto mb-6">
                1
              </div>
              <h3 className="text-xl font-display font-semibold mb-4">Start a Project</h3>
              <p className="text-gray-600">
                Create your project with details about your idea, funding goals, and rewards for backers.
              </p>
            </motion.div>

            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.2 }}
            >
              <div className="w-20 h-20 bg-secondary-100 text-secondary-600 flex items-center justify-center rounded-full text-2xl font-bold mx-auto mb-6">
                2
              </div>
              <h3 className="text-xl font-display font-semibold mb-4">Get Funded</h3>
              <p className="text-gray-600">
                Share your project and connect with a community excited about your idea to reach your funding goal.
              </p>
            </motion.div>

            <motion.div 
              className="text-center"
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: 0.4 }}
            >
              <div className="w-20 h-20 bg-accent-100 text-accent-600 flex items-center justify-center rounded-full text-2xl font-bold mx-auto mb-6">
                3
              </div>
              <h3 className="text-xl font-display font-semibold mb-4">Make It Happen</h3>
              <p className="text-gray-600">
                Bring your project to life with the support of your backers and keep them updated on your progress.
              </p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA section */}
      <section className="py-16 bg-secondary-600 text-white">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-3xl font-display font-bold mb-6">
              Ready to bring your idea to life?
            </h2>
            <p className="text-lg opacity-90 mb-8">
              Join thousands of creators who have successfully funded their projects on FundStart.
            </p>
            <div className="flex flex-col sm:flex-row justify-center space-y-4 sm:space-y-0 sm:space-x-4">
              {currentUser ? (
                <Link to="/create" className="btn bg-white text-secondary-600 hover:bg-gray-100 btn-lg">
                  Start a Project
                </Link>
              ) : (
                <button 
                  onClick={() => openAuthModal('signup')} 
                  className="btn bg-white text-secondary-600 hover:bg-gray-100 btn-lg"
                >
                  Start a Project
                </button>
              )}
              <Link to="/discover" className="btn btn-outline border-white text-white hover:bg-secondary-700 btn-lg">
                Explore Projects
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  )
}