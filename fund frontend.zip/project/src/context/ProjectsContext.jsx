import { createContext, useState, useContext, useEffect } from 'react'
import { format } from 'date-fns'
import { mockProjects } from '../data/mockProjects'

const ProjectsContext = createContext(null)

export const useProjects = () => useContext(ProjectsContext)

export const ProjectsProvider = ({ children }) => {
  const [projects, setProjects] = useState([])
  const [featuredProjects, setFeaturedProjects] = useState([])
  const [categories, setCategories] = useState([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // In a real app, this would be an API call
    // For demo purposes, we'll use mock data
    const loadProjects = () => {
      const storedProjects = localStorage.getItem('fundstartProjects')
      if (storedProjects) {
        setProjects(JSON.parse(storedProjects))
      } else {
        setProjects(mockProjects)
        localStorage.setItem('fundstartProjects', JSON.stringify(mockProjects))
      }

      // Set featured projects (top 3 by percentage funded)
      const sortedProjects = [...mockProjects].sort((a, b) => {
        const percentA = (a.funded / a.goal) * 100
        const percentB = (b.funded / b.goal) * 100
        return percentB - percentA
      })
      
      setFeaturedProjects(sortedProjects.slice(0, 3))
      
      // Extract unique categories
      const uniqueCategories = [...new Set(mockProjects.map(project => project.category))]
      setCategories(uniqueCategories)
      
      setLoading(false)
    }

    loadProjects()
  }, [])

  // Get project by ID
  const getProject = (id) => {
    return projects.find(project => project.id === id)
  }

  // Get projects by category
  const getProjectsByCategory = (category) => {
    if (category === 'all') return projects
    return projects.filter(project => project.category === category)
  }

  // Create a new project
  const createProject = (projectData) => {
    const newProject = {
      id: `project${Date.now()}`,
      createdAt: format(new Date(), 'PPP'),
      funded: 0,
      backers: 0,
      updates: [],
      comments: [],
      ...projectData
    }

    const updatedProjects = [newProject, ...projects]
    setProjects(updatedProjects)
    localStorage.setItem('fundstartProjects', JSON.stringify(updatedProjects))
    
    return newProject
  }

  // Back a project (make a pledge)
  const backProject = (projectId, amount, userId, reward = null) => {
    const updatedProjects = projects.map(project => {
      if (project.id === projectId) {
        // Add backer and amount
        return {
          ...project,
          funded: project.funded + Number(amount),
          backers: project.backers + 1,
        }
      }
      return project
    })

    setProjects(updatedProjects)
    localStorage.setItem('fundstartProjects', JSON.stringify(updatedProjects))
    
    return getProject(projectId)
  }

  const value = {
    projects,
    featuredProjects,
    categories,
    loading,
    getProject,
    getProjectsByCategory,
    createProject,
    backProject
  }

  return (
    <ProjectsContext.Provider value={value}>
      {children}
    </ProjectsContext.Provider>
  )
}