export const mockProjects = [
  {
    id: 'project1',
    title: 'EcoFresh: Sustainable Food Storage',
    description: 'Revolutionary food storage containers made from biodegradable materials that keep your food fresh longer while reducing plastic waste.',
    longDescription: `
      # EcoFresh: Sustainable Food Storage

      ## About
      
      EcoFresh is revolutionizing food storage with our innovative containers made from 100% biodegradable materials. Our patent-pending design keeps your food fresh for up to 5 days longer than traditional containers, while completely breaking down in compost within 6 months.

      ## The Problem

      Plastic containers are polluting our planet. Over 8 million metric tons of plastic enter our oceans every year, and food storage containers are a significant contributor. Traditional "eco-friendly" alternatives don't keep food fresh enough, forcing consumers to choose between food waste and plastic waste.

      ## Our Solution

      EcoFresh containers use our innovative plant-based polymer that creates an airtight, moisture-regulating seal – keeping your produce, leftovers, and meal preps fresher for longer. Each container is:

      - 100% biodegradable and compostable
      - Free from BPA, phthalates, and other harmful chemicals
      - Microwave, freezer, and dishwasher safe
      - Clear, so you can see what's inside
      - Durable for hundreds of uses

      ## How We'll Use The Funds

      - 40% - Finalizing our manufacturing process
      - 25% - Initial production run
      - 15% - Certifications and testing
      - 10% - Packaging and shipping
      - 10% - Marketing and awareness

      ## Our Team

      We're a team of materials scientists, environmental activists, and food lovers who believe you shouldn't have to choose between convenience and sustainability.

      Join us in revolutionizing how people store food while protecting our planet for future generations.
    `,
    imageUrl: 'https://images.pexels.com/photos/5202159/pexels-photo-5202159.jpeg',
    goal: 50000,
    funded: 37500,
    backers: 823,
    daysLeft: 12,
    category: 'Eco',
    createdAt: 'October 15, 2023',
    creator: {
      name: 'GreenLife Innovations',
      avatar: 'https://randomuser.me/api/portraits/women/65.jpg',
      bio: 'Creating sustainable solutions for everyday problems'
    },
    rewards: [
      {
        id: 'reward1-1',
        title: 'Early Bird Special',
        description: 'Get a set of 3 EcoFresh containers (small, medium, large) at 25% off retail price.',
        amount: 35,
        claimed: 412,
        available: 500,
        estimatedDelivery: 'March 2024'
      },
      {
        id: 'reward1-2',
        title: 'Family Pack',
        description: 'Get a complete set of 10 EcoFresh containers in various sizes, perfect for meal prep and leftover storage.',
        amount: 90,
        claimed: 267,
        available: null,
        estimatedDelivery: 'March 2024'
      },
      {
        id: 'reward1-3',
        title: 'Sustainability Champion',
        description: 'Receive the Family Pack plus an exclusive tote bag made from recycled ocean plastic and your name on our Founders Wall.',
        amount: 150,
        claimed: 89,
        available: 100,
        estimatedDelivery: 'April 2024'
      }
    ],
    updates: [
      {
        id: 'update1-1',
        date: 'November 1, 2023',
        title: 'Production Sample Approval!',
        content: 'We've just received and approved the final production samples! The containers are even better than we hoped - crystal clear, durable, and they passed all our freshness tests with flying colors.'
      },
      {
        id: 'update1-2',
        date: 'October 22, 2023',
        title: 'Thank you for an amazing first week!',
        content: 'We're absolutely blown away by your support. In just one week, we've reached 50% of our funding goal! This validation means the world to us.'
      }
    ],
    comments: [
      {
        id: 'comment1-1',
        user: {
          name: 'Morgan Lee',
          avatar: 'https://randomuser.me/api/portraits/women/32.jpg'
        },
        date: 'October 28, 2023',
        content: 'I've been looking for something exactly like this! Can't wait to replace all my plastic containers.'
      },
      {
        id: 'comment1-2',
        user: {
          name: 'Alex Johnson',
          avatar: 'https://randomuser.me/api/portraits/men/15.jpg'
        },
        date: 'October 23, 2023',
        content: 'What temperature can these withstand in the microwave? I'm concerned about warping.'
      },
      {
        id: 'comment1-3',
        user: {
          name: 'Riley Chen',
          avatar: 'https://randomuser.me/api/portraits/women/22.jpg'
        },
        date: 'October 20, 2023',
        content: 'Just backed the Family Pack! Question: do these nest together for storage?'
      }
    ]
  },
  {
    id: 'project2',
    title: 'Nomad Coffee: Portable Espresso Maker',
    description: 'The ultimate portable espresso maker for travelers and outdoor enthusiasts. Barista-quality coffee anywhere, anytime, without electricity.',
    longDescription: `
      # Nomad Coffee: Portable Espresso Maker

      ## About
      
      Nomad Coffee is the ultimate portable espresso maker that delivers barista-quality coffee anywhere. Designed for travelers, outdoor enthusiasts, and coffee lovers who refuse to compromise on quality, Nomad Coffee brings the café experience to even the most remote locations.

      ## The Problem

      Coffee lovers face a painful dilemma when traveling or enjoying the outdoors: either sacrifice quality with instant coffee or go without their favorite brew altogether. Existing portable coffee makers are either too bulky, too fragile, difficult to clean, or simply incapable of producing true espresso with crema.

      ## Our Solution

      Nomad Coffee uses our patented pressure system to deliver 9 bars of pressure - the gold standard for espresso extraction - without electricity or batteries. Our design features:

      - Compact size that fits in your backpack, carry-on, or desk drawer
      - Durable aerospace-grade aluminum construction
      - Easy cleaning design with minimal parts
      - Compatibility with both ground coffee and standard ESE pods
      - Consistent temperature control for perfect extraction
      - Built-in cup and water reservoir

      ## How We'll Use The Funds

      - 45% - Production tooling and initial manufacturing run
      - 20% - Finalizing our patented pressure mechanism
      - 15% - Quality testing and certification
      - 10% - Packaging and distribution setup
      - 10% - Marketing and customer education

      ## Our Team

      Our team combines expertise in mechanical engineering, industrial design, and a deep passion for coffee. We've spent two years perfecting the Nomad Coffee prototype, testing it in various environments from city apartments to mountain peaks.

      Join us in ensuring that great coffee is available anywhere your adventures take you.
    `,
    imageUrl: 'https://images.pexels.com/photos/312418/pexels-photo-312418.jpeg',
    goal: 30000,
    funded: 28500,
    backers: 692,
    daysLeft: 5,
    category: 'Food & Drink',
    createdAt: 'November 3, 2023',
    creator: {
      name: 'Nomad Brewing Co',
      avatar: 'https://randomuser.me/api/portraits/men/22.jpg',
      bio: 'Coffee enthusiasts dedicated to perfect brews anywhere'
    },
    rewards: [
      {
        id: 'reward2-1',
        title: 'Early Bird Espresso',
        description: 'Get the Nomad Coffee portable espresso maker at 20% off retail price. Be the first to enjoy espresso anywhere.',
        amount: 60,
        claimed: 350,
        available: 350,
        estimatedDelivery: 'February 2024'
      },
      {
        id: 'reward2-2',
        title: 'Complete Traveler Kit',
        description: 'The Nomad Coffee maker plus our specially designed travel case, collapsible cup, and a 3-month subscription of our specialty coffee beans.',
        amount: 95,
        claimed: 275,
        available: null,
        estimatedDelivery: 'February 2024'
      },
      {
        id: 'reward2-3',
        title: 'Barista Bundle',
        description: 'Two Nomad Coffee makers, travel accessories, 6-month coffee subscription, and an online masterclass with our head barista.',
        amount: 180,
        claimed: 67,
        available: 100,
        estimatedDelivery: 'February 2024'
      }
    ],
    updates: [
      {
        id: 'update2-1',
        date: 'November 10, 2023',
        title: 'Final color options selected!',
        content: 'After your feedback, we've finalized the color options: Matte Black, Brushed Silver, and limited-edition Copper (for our Barista Bundle backers only).'
      }
    ],
    comments: [
      {
        id: 'comment2-1',
        user: {
          name: 'Jamie Wilson',
          avatar: 'https://randomuser.me/api/portraits/men/43.jpg'
        },
        date: 'November 12, 2023',
        content: 'As someone who travels for work constantly, this is exactly what I've been looking for. Does it work with all types of coffee grounds?'
      },
      {
        id: 'comment2-2',
        user: {
          name: 'Sam Taylor',
          avatar: 'https://randomuser.me/api/portraits/women/57.jpg'
        },
        date: 'November 8, 2023',
        content: 'Just backed! Question: what's the capacity of each shot?'
      }
    ]
  },
  {
    id: 'project3',
    title: 'SleepSync: Smart Sleep Tracking Mattress Topper',
    description: 'A non-invasive sleep tracking solution that turns any mattress into a smart bed, providing actionable insights to improve your sleep quality.',
    longDescription: `
      # SleepSync: Smart Sleep Tracking Mattress Topper

      ## About
      
      SleepSync transforms any mattress into a comprehensive sleep lab with our innovative mattress topper. Unlike wearables that can be uncomfortable and inaccurate, SleepSync works invisibly beneath you to track and improve your sleep.

      ## The Problem

      Sleep disorders and poor sleep quality affect over 70 million Americans, costing the economy billions in lost productivity and healthcare costs. Current tracking solutions require wearing devices that can interfere with sleep, produce inaccurate results, or require significant lifestyle changes.

      ## Our Solution

      SleepSync uses medical-grade sensors embedded in a comfortable, breathable mattress topper to track:

      - Sleep cycles and stages (REM, deep, light)
      - Heart rate and heart rate variability
      - Breathing patterns and disturbances
      - Movement and restlessness
      - Temperature regulation
      - Environmental factors (room temperature, humidity, ambient light)

      Our AI-powered app provides personalized insights and recommendations that actually improve your sleep quality over time, not just measure its decline.

      ## How We'll Use The Funds

      - 35% - Finalizing our sensor technology and manufacturing setup
      - 25% - App development and AI algorithm refinement
      - 20% - Clinical validation studies
      - 10% - Quality assurance and testing
      - 10% - Production and fulfillment preparations

      ## Our Team

      Our team brings together expertise in sleep medicine, textile engineering, data science, and consumer technology. We've been developing SleepSync for three years, including successful pilot studies with sleep clinics.

      Join us in revolutionizing how people understand and improve their sleep quality.
    `,
    imageUrl: 'https://images.pexels.com/photos/6585601/pexels-photo-6585601.jpeg',
    goal: 100000,
    funded: 32000,
    backers: 245,
    daysLeft: 21,
    category: 'Health & Wellness',
    createdAt: 'October 28, 2023',
    creator: {
      name: 'SleepTech Innovations',
      avatar: 'https://randomuser.me/api/portraits/men/78.jpg',
      bio: 'Using technology to improve sleep health for everyone'
    },
    rewards: [
      {
        id: 'reward3-1',
        title: 'Early Bird Single',
        description: 'One SleepSync mattress topper (Twin/Twin XL size) with lifetime access to the basic sleep insights app.',
        amount: 199,
        claimed: 87,
        available: 100,
        estimatedDelivery: 'May 2024'
      },
      {
        id: 'reward3-2',
        title: 'Queen/King Size',
        description: 'One SleepSync mattress topper (Queen or King size) with 1 year of premium app features.',
        amount: 259,
        claimed: 112,
        available: null,
        estimatedDelivery: 'May 2024'
      },
      {
        id: 'reward3-3',
        title: 'Couples Bundle',
        description: 'Two individual SleepSync trackers for Queen/King beds with dual-zone tracking, plus lifetime premium app features and a sleep consultation.',
        amount: 499,
        claimed: 46,
        available: 75,
        estimatedDelivery: 'June 2024'
      }
    ],
    updates: [
      {
        id: 'update3-1',
        date: 'November 15, 2023',
        title: 'Clinical Trial Results Are In!',
        content: 'We're excited to share that our independent clinical trial showed SleepSync was 96% as accurate as professional polysomnography for detecting sleep stages. Full report available to backers!'
      }
    ],
    comments: [
      {
        id: 'comment3-1',
        user: {
          name: 'Jordan Smith',
          avatar: 'https://randomuser.me/api/portraits/women/11.jpg'
        },
        date: 'November 17, 2023',
        content: 'As someone with sleep apnea, would this help track my episodes through the night?'
      }
    ]
  },
  {
    id: 'project4',
    title: 'EverNote: The Self-Charging Digital Notebook',
    description: 'A revolutionary e-ink notebook that charges itself from ambient light. Never worry about battery life or lost notes again.',
    longDescription: `
      # EverNote: The Self-Charging Digital Notebook

      ## About
      
      EverNote combines the tactile pleasure of writing in a notebook with the convenience of digital storage in a device that never needs to be plugged in. Our groundbreaking technology harvests energy from ambient light, ensuring your notes are always accessible and your device is always ready.

      ## The Problem

      Digital note-taking devices offer great functionality but suffer from battery anxiety, screen glare, and complex interfaces. Traditional notebooks are simple and satisfying to use, but lack searchability, backup capabilities, and environmental sustainability.

      ## Our Solution

      EverNote brings together the best of both worlds with:

      - Custom e-ink display with paper-like texture and feel
      - Proprietary light-harvesting technology that powers the device from indoor or outdoor light
      - Pressure-sensitive stylus that captures even the subtlest strokes
      - Simple, distraction-free interface focused on writing
      - Automatic cloud backup when near your phone or wifi
      - Sustainable materials including recycled aluminum and bioplastics

      ## How We'll Use The Funds

      - 40% - Finalizing our energy harvesting technology
      - 25% - Display technology optimization
      - 15% - App ecosystem development 
      - 10% - Sustainable materials sourcing and testing
      - 10% - Initial production setup

      ## Our Team

      Our team combines expertise in renewable energy, materials science, and product design. We've been developing the core technology behind EverNote for over four years, with multiple patents pending.

      Join us in creating a more sustainable approach to capturing and preserving your ideas.
    `,
    imageUrl: 'https://images.pexels.com/photos/6469/red-hands-woman-creative.jpg',
    goal: 85000,
    funded: 25500,
    backers: 201,
    daysLeft: 33,
    category: 'Technology',
    createdAt: 'October 30, 2023',
    creator: {
      name: 'Infinite Ideas Inc.',
      avatar: 'https://randomuser.me/api/portraits/women/28.jpg',
      bio: 'Creating thoughtful technology for creative minds'
    },
    rewards: [
      {
        id: 'reward4-1',
        title: 'Early Adopter',
        description: 'Be among the first to receive the EverNote digital notebook in Charcoal Gray, including premium stylus.',
        amount: 220,
        claimed: 160,
        available: 200,
        estimatedDelivery: 'July 2024'
      },
      {
        id: 'reward4-2',
        title: 'Creator Pack',
        description: 'EverNote notebook, two styluses with different tip sizes, premium vegan leather sleeve, and priority access to new features.',
        amount: 300,
        claimed: 32,
        available: null,
        estimatedDelivery: 'July 2024'
      },
      {
        id: 'reward4-3',
        title: 'Studio Bundle',
        description: 'Two EverNote notebooks, complete accessory set, exclusive early access to desktop sync software, and virtual workshop with our design team.',
        amount: 550,
        claimed: 9,
        available: 50,
        estimatedDelivery: 'August 2024'
      }
    ],
    updates: [],
    comments: [
      {
        id: 'comment4-1',
        user: {
          name: 'Taylor Ross',
          avatar: 'https://randomuser.me/api/portraits/men/55.jpg'
        },
        date: 'November 3, 2023',
        content: 'This looks amazing! How many pages can it store before needing to sync to the cloud?'
      }
    ]
  },
  {
    id: 'project5',
    title: 'Urban Oasis: Modular Indoor Garden System',
    description: 'A space-efficient vertical gardening system that makes growing food at home easy, even with minimal space and natural light.',
    longDescription: `
      # Urban Oasis: Modular Indoor Garden System

      ## About
      
      Urban Oasis brings abundant homegrown food into any living space with our beautiful, functional, and amazingly productive vertical garden system. Designed specifically for apartments and small homes, Urban Oasis makes growing food possible regardless of outdoor space or gardening experience.

      ## The Problem

      Urban dwellers increasingly want to grow their own food for health, sustainability, and pleasure, but face significant barriers: limited space, insufficient natural light, lack of gardening knowledge, and complex hydroponic systems that are eyesores in living spaces.

      ## Our Solution

      Urban Oasis solves these challenges with a system that is:

      - Modular and expandable - start small and grow your system over time
      - Beautifully designed to complement home decor, not detract from it
      - Self-regulating with smart sensors that monitor plant health and automate care
      - Energy-efficient with specialized LED lighting that mimics natural sunlight
      - Simple to use with pre-seeded plant pods and guided growing via our app
      - Space-efficient, producing up to 30 plants in just 4 square feet of floor space

      ## How We'll Use The Funds

      - 35% - Production tooling and initial manufacturing 
      - 25% - Refinement of our plant pod technology and varieties
      - 15% - App development and plant care algorithm optimization
      - 15% - Supply chain setup and quality assurance
      - 10% - Sustainable packaging design and implementation

      ## Our Team

      Our team brings together expertise in horticulture, product design, and urban living. We've spent three years developing and testing Urban Oasis in real apartments across different climate zones.

      Join us in bringing the joy and benefits of growing food to urban environments.
    `,
    imageUrl: 'https://images.pexels.com/photos/793765/pexels-photo-793765.jpeg',
    goal: 75000,
    funded: 18000,
    backers: 124,
    daysLeft: 25,
    category: 'Home',
    createdAt: 'November 2, 2023',
    creator: {
      name: 'Urban Botanicals',
      avatar: 'https://randomuser.me/api/portraits/women/78.jpg',
      bio: 'Making food growing accessible to everyone, everywhere'
    },
    rewards: [
      {
        id: 'reward5-1',
        title: 'Window Garden',
        description: 'The Urban Oasis starter module with 12 growing spaces, lighting, and 3 months of plant pods.',
        amount: 175,
        claimed: 86,
        available: 150,
        estimatedDelivery: 'June 2024'
      },
      {
        id: 'reward5-2',
        title: 'Kitchen Garden',
        description: 'Two connected Urban Oasis modules (24 plants total), premium wood exterior option, and 6 months of plant pods.',
        amount: 320,
        claimed: 29,
        available: null,
        estimatedDelivery: 'June 2024'
      },
      {
        id: 'reward5-3',
        title: 'Home Garden System',
        description: 'Complete three-module system (36 plants) with premium finishes, 1 year of plant pods, and exclusive early access to specialty herb and flower pods.',
        amount: 450,
        claimed: 9,
        available: 50,
        estimatedDelivery: 'July 2024'
      }
    ],
    updates: [
      {
        id: 'update5-1',
        date: 'November 16, 2023',
        title: 'New Herb Varieties Added!',
        content: 'Thanks to your amazing support, we've reached the stretch goal to develop premium herb varieties! All backers will now receive access to basil, cilantro, mint, thyme, and rosemary pods.'
      }
    ],
    comments: [
      {
        id: 'comment5-1',
        user: {
          name: 'Casey Kim',
          avatar: 'https://randomuser.me/api/portraits/women/72.jpg'
        },
        date: 'November 10, 2023',
        content: 'How much electricity does the lighting system use on average?'
      }
    ]
  },
  {
    id: 'project6',
    title: 'RetroTech: Classic Gaming Console Reimagined',
    description: 'Experience the golden age of gaming with modern convenience. This handcrafted console plays thousands of classic games with stunning visual upgrades.',
    longDescription: `
      # RetroTech: Classic Gaming Console Reimagined

      ## About
      
      RetroTech brings the magic of classic gaming into the modern era with our handcrafted console. Combining the authentic feel of vintage gaming with today's technology, RetroTech delivers thousands of games from the 8-bit, 16-bit, and 32-bit eras with stunning visual enhancements and quality-of-life improvements.

      ## The Problem

      Classic games are an important part of our cultural heritage, but experiencing them today often means dealing with obsolete hardware, compatibility issues, or poor emulation. Legal access to classic games is increasingly difficult as older systems fail and digital stores close.

      ## Our Solution

      RetroTech solves these challenges with a system that offers:

      - Authentic, lag-free gameplay for thousands of classic titles
      - Legal emulation through our partnerships with game publishers
      - Multiple graphic modes including original, enhanced, and CRT simulation
      - Wireless controllers with the exact feel of the originals
      - Modern connections including HDMI, Bluetooth, and WiFi
      - Expandable library through our curated game marketplace
      - Handcrafted wooden console design that's both nostalgic and timeless

      ## How We'll Use The Funds

      - 30% - Manufacturing setup and initial production
      - 25% - Software development and emulation optimization
      - 20% - Game licensing and publisher partnerships
      - 15% - Quality assurance and testing across thousands of games
      - 10% - Logistical infrastructure and fulfillment preparation

      ## Our Team

      Our team brings together expertise in hardware engineering, software development, and gaming history. Many of us worked on the original systems we're now preserving, and all of us are passionate about keeping classic games playable for future generations.

      Join us in preserving and celebrating gaming history while creating new ways to experience these timeless classics.
    `,
    imageUrl: 'https://images.pexels.com/photos/442576/pexels-photo-442576.jpeg',
    goal: 120000,
    funded: 96000,
    backers: 1250,
    daysLeft: 8,
    category: 'Games',
    createdAt: 'October 20, 2023',
    creator: {
      name: 'Pixel Perfect Gaming',
      avatar: 'https://randomuser.me/api/portraits/men/7.jpg',
      bio: 'Preserving gaming history through modern technology'
    },
    rewards: [
      {
        id: 'reward6-1',
        title: 'Early Bird Console',
        description: 'The RetroTech console with one wireless controller and 100 pre-loaded games from various classic systems.',
        amount: 180,
        claimed: 750,
        available: 750,
        estimatedDelivery: 'April 2024'
      },
      {
        id: 'reward6-2',
        title: 'Deluxe Edition',
        description: 'RetroTech console, two wireless controllers, 500 pre-loaded games, and exclusive access to limited edition title releases.',
        amount: 250,
        claimed: 425,
        available: null,
        estimatedDelivery: 'April 2024'
      },
      {
        id: 'reward6-3',
        title: 'Collector's Bundle',
        description: 'Premium wood finish console, complete controller set (4 controllers), all available games, hardcover art book, and your name in the credits.',
        amount: 400,
        claimed: 75,
        available: 100,
        estimatedDelivery: 'May 2024'
      }
    ],
    updates: [
      {
        id: 'update6-1',
        date: 'November 15, 2023',
        title: 'New Publisher Partnership!',
        content: 'We're thrilled to announce we've secured a partnership with Vintage Games Inc. to bring their entire classic catalog to RetroTech! This adds over 200 additional titles to our library.'
      },
      {
        id: 'update6-2',
        date: 'November 1, 2023',
        title: 'Production Prototype Complete',
        content: 'The final production prototype is complete and has passed all our rigorous testing procedures. We've included photos of the finished hardware for you to enjoy!'
      }
    ],
    comments: [
      {
        id: 'comment6-1',
        user: {
          name: 'Robin Chen',
          avatar: 'https://randomuser.me/api/portraits/men/22.jpg'
        },
        date: 'November 16, 2023',
        content: 'Will we be able to add ROMs of games we already own legally?'
      },
      {
        id: 'comment6-2',
        user: {
          name: 'Dana Lopez',
          avatar: 'https://randomuser.me/api/portraits/women/39.jpg'
        },
        date: 'November 5, 2023',
        content: 'Just backed the Collector's Bundle! Which systems will be supported at launch?'
      }
    ]
  }
]