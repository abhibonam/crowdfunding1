package com.fundstart.service;

import com.fundstart.dto.ProjectDTO;
import com.fundstart.model.Project;
import com.fundstart.model.User;
import com.fundstart.repository.ProjectRepository;
import com.fundstart.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ProjectService {
    private final ProjectRepository projectRepository;
    private final UserRepository userRepository;

    public List<ProjectDTO> getAllProjects(String category, String sort) {
        List<Project> projects;
        
        if (category != null) {
            projects = projectRepository.findByCategory(category);
        } else {
            projects = projectRepository.findAll();
        }

        // Apply sorting
        switch (sort) {
            case "newest":
                projects.sort((a, b) -> b.getCreatedAt().compareTo(a.getCreatedAt()));
                break;
            case "endingSoon":
                projects.sort((a, b) -> a.getEndDate().compareTo(b.getEndDate()));
                break;
            case "mostFunded":
                projects.sort((a, b) -> b.getFunded().compareTo(a.getFunded()));
                break;
            default: // trending
                projects.sort((a, b) -> {
                    BigDecimal percentA = a.getFunded().divide(a.getGoal(), 2, BigDecimal.ROUND_HALF_UP);
                    BigDecimal percentB = b.getFunded().divide(b.getGoal(), 2, BigDecimal.ROUND_HALF_UP);
                    return percentB.compareTo(percentA);
                });
        }

        return projects.stream()
                .map(ProjectDTO::fromProject)
                .collect(Collectors.toList());
    }

    public ProjectDTO getProject(UUID id) {
        Project project = projectRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Project not found"));
        return ProjectDTO.fromProject(project);
    }

    @Transactional
    public ProjectDTO createProject(ProjectDTO projectDTO) {
        String userEmail = SecurityContextHolder.getContext().getAuthentication().getName();
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));

        Project project = projectDTO.toProject();
        project.setCreator(user);
        
        Project savedProject = projectRepository.save(project);
        return ProjectDTO.fromProject(savedProject);
    }

    @Transactional
    public ProjectDTO pledgeToProject(UUID projectId, UUID rewardId, Double amount) {
        // Implementation for pledging to a project
        // This would include validating the reward, updating pledge counts,
        // and creating the pledge record
        return null; // TODO: Implement pledge logic
    }
}