package com.fundstart.dto;

import com.fundstart.model.Project;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;

@Data
public class ProjectDTO {
    private UUID id;
    private String title;
    private String description;
    private String longDescription;
    private String category;
    private BigDecimal goal;
    private BigDecimal funded;
    private String imageUrl;
    private LocalDateTime endDate;
    private UserDTO creator;
    private Set<RewardDTO> rewards;
    private Set<UpdateDTO> updates;
    private Set<CommentDTO> comments;
    private LocalDateTime createdAt;
    private int backers;
    private int daysLeft;

    public static ProjectDTO fromProject(Project project) {
        ProjectDTO dto = new ProjectDTO();
        dto.setId(project.getId());
        dto.setTitle(project.getTitle());
        dto.setDescription(project.getDescription());
        dto.setLongDescription(project.getLongDescription());
        dto.setCategory(project.getCategory());
        dto.setGoal(project.getGoal());
        dto.setFunded(project.getFunded());
        dto.setImageUrl(project.getImageUrl());
        dto.setEndDate(project.getEndDate());
        dto.setCreator(UserDTO.fromUser(project.getCreator()));
        dto.setRewards(project.getRewards().stream()
                .map(RewardDTO::fromReward)
                .collect(Collectors.toSet()));
        dto.setUpdates(project.getUpdates().stream()
                .map(UpdateDTO::fromUpdate)
                .collect(Collectors.toSet()));
        dto.setComments(project.getComments().stream()
                .map(CommentDTO::fromComment)
                .collect(Collectors.toSet()));
        dto.setCreatedAt(project.getCreatedAt());
        dto.setBackers(project.getPledges().size());
        
        // Calculate days left
        long daysLeft = java.time.temporal.ChronoUnit.DAYS.between(
                LocalDateTime.now(),
                project.getEndDate()
        );
        dto.setDaysLeft((int) daysLeft);
        
        return dto;
    }

    public Project toProject() {
        Project project = new Project();
        project.setTitle(this.title);
        project.setDescription(this.description);
        project.setLongDescription(this.longDescription);
        project.setCategory(this.category);
        project.setGoal(this.goal);
        project.setImageUrl(this.imageUrl);
        project.setEndDate(this.endDate);
        return project;
    }
}