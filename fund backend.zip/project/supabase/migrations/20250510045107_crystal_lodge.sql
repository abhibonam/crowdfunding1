/*
  # Initial Schema Setup for Crowdfunding Platform

  1. New Tables
    - `profiles`
      - User profiles with additional information
    - `projects`
      - Crowdfunding projects
    - `rewards`
      - Project reward tiers
    - `pledges`
      - User pledges/backings
    - `updates`
      - Project updates
    - `comments`
      - Project comments

  2. Security
    - Enable RLS on all tables
    - Add policies for authenticated users
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  name text NOT NULL,
  avatar_url text,
  bio text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create projects table
CREATE TABLE IF NOT EXISTS projects (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id uuid REFERENCES profiles(id) NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  long_description text NOT NULL,
  category text NOT NULL,
  goal numeric NOT NULL CHECK (goal > 0),
  funded numeric DEFAULT 0 CHECK (funded >= 0),
  image_url text NOT NULL,
  end_date timestamptz NOT NULL,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create rewards table
CREATE TABLE IF NOT EXISTS rewards (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text NOT NULL,
  amount numeric NOT NULL CHECK (amount > 0),
  estimated_delivery text NOT NULL,
  available_count integer,
  claimed_count integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create pledges table
CREATE TABLE IF NOT EXISTS pledges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) NOT NULL,
  reward_id uuid REFERENCES rewards(id),
  amount numeric NOT NULL CHECK (amount > 0),
  created_at timestamptz DEFAULT now()
);

-- Create updates table
CREATE TABLE IF NOT EXISTS updates (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Create comments table
CREATE TABLE IF NOT EXISTS comments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id uuid REFERENCES projects(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) NOT NULL,
  content text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE rewards ENABLE ROW LEVEL SECURITY;
ALTER TABLE pledges ENABLE ROW LEVEL SECURITY;
ALTER TABLE updates ENABLE ROW LEVEL SECURITY;
ALTER TABLE comments ENABLE ROW LEVEL SECURITY;

-- Profiles policies
CREATE POLICY "Public profiles are viewable by everyone"
  ON profiles
  FOR SELECT
  USING (true);

CREATE POLICY "Users can update own profile"
  ON profiles
  FOR UPDATE
  USING (auth.uid() = id);

-- Projects policies
CREATE POLICY "Projects are viewable by everyone"
  ON projects
  FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create projects"
  ON projects
  FOR INSERT
  WITH CHECK (auth.uid() = creator_id);

CREATE POLICY "Creators can update own projects"
  ON projects
  FOR UPDATE
  USING (auth.uid() = creator_id);

-- Rewards policies
CREATE POLICY "Rewards are viewable by everyone"
  ON rewards
  FOR SELECT
  USING (true);

CREATE POLICY "Project creators can manage rewards"
  ON rewards
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT creator_id FROM projects WHERE id = project_id
    )
  );

-- Pledges policies
CREATE POLICY "Users can view own pledges"
  ON pledges
  FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Project creators can view project pledges"
  ON pledges
  FOR SELECT
  USING (
    auth.uid() IN (
      SELECT creator_id FROM projects WHERE id = project_id
    )
  );

CREATE POLICY "Authenticated users can create pledges"
  ON pledges
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- Updates policies
CREATE POLICY "Updates are viewable by everyone"
  ON updates
  FOR SELECT
  USING (true);

CREATE POLICY "Project creators can manage updates"
  ON updates
  FOR ALL
  USING (
    auth.uid() IN (
      SELECT creator_id FROM projects WHERE id = project_id
    )
  );

-- Comments policies
CREATE POLICY "Comments are viewable by everyone"
  ON comments
  FOR SELECT
  USING (true);

CREATE POLICY "Authenticated users can create comments"
  ON comments
  FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own comments"
  ON comments
  FOR DELETE
  USING (auth.uid() = user_id);