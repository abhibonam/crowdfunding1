package com.fundstart.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Data;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;

@Data
@Entity
@Table(name = "pledges")
@EntityListeners(AuditingEntityListener.class)
public class Pledge {
    @Id
    @GeneratedValue
    private UUID id;

    @NotNull
    @Positive
    private BigDecimal amount;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private Project project;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne
    @JoinColumn(name = "reward_id")
    private Reward reward;

    @CreatedDate
    private LocalDateTime createdAt;
}