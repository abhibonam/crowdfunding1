package com.fundstart.dto;

import com.fundstart.model.Update;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.UUID;

@Data
public class UpdateDTO {
    private UUID id;
    private String title;
    private String content;
    private LocalDateTime createdAt;

    public static UpdateDTO fromUpdate(Update update) {
        UpdateDTO dto = new UpdateDTO();
        dto.setId(update.getId());
        dto.setTitle(update.getTitle());
        dto.setContent(update.getContent());
        dto.setCreatedAt(update.getCreatedAt());
        return dto;
    }
}