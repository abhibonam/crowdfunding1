import { motion } from 'framer-motion'

// Map categories to colors
const categoryColors = {
  all: 'primary',
  Technology: 'blue',
  Games: 'indigo',
  'Food & Drink': 'yellow',
  Eco: 'green',
  'Health & Wellness': 'red',
  Home: 'purple',
  // Default to primary for any new categories
}

export default function CategoryButton({ category, label, selected, onClick }) {
  const colorKey = categoryColors[category] || 'primary'
  
  // Define color classes based on selection state
  const getColorClass = () => {
    if (selected) {
      switch (colorKey) {
        case 'primary': return 'bg-primary-500 text-white';
        case 'blue': return 'bg-blue-500 text-white';
        case 'indigo': return 'bg-indigo-500 text-white';
        case 'yellow': return 'bg-yellow-500 text-white';
        case 'green': return 'bg-green-500 text-white';
        case 'red': return 'bg-red-500 text-white';
        case 'purple': return 'bg-purple-500 text-white';
        default: return 'bg-primary-500 text-white';
      }
    } else {
      switch (colorKey) {
        case 'primary': return 'bg-white text-primary-600 hover:bg-primary-50';
        case 'blue': return 'bg-white text-blue-600 hover:bg-blue-50';
        case 'indigo': return 'bg-white text-indigo-600 hover:bg-indigo-50';
        case 'yellow': return 'bg-white text-yellow-600 hover:bg-yellow-50';
        case 'green': return 'bg-white text-green-600 hover:bg-green-50';
        case 'red': return 'bg-white text-red-600 hover:bg-red-50';
        case 'purple': return 'bg-white text-purple-600 hover:bg-purple-50';
        default: return 'bg-white text-primary-600 hover:bg-primary-50';
      }
    }
  }

  return (
    <motion.button
      whileHover={{ scale: 1.05 }}
      whileTap={{ scale: 0.95 }}
      className={`px-6 py-2 rounded-full font-medium text-sm shadow-sm transition-colors border ${selected ? 'border-transparent' : 'border-gray-200'} ${getColorClass()}`}
      onClick={onClick}
    >
      {label}
    </motion.button>
  )
}