package com.fundstart.dto;

import com.fundstart.model.Reward;
import lombok.Data;

import java.math.BigDecimal;
import java.util.UUID;

@Data
public class RewardDTO {
    private UUID id;
    private String title;
    private String description;
    private BigDecimal amount;
    private String estimatedDelivery;
    private Integer availableCount;
    private Integer claimedCount;

    public static RewardDTO fromReward(Reward reward) {
        RewardDTO dto = new RewardDTO();
        dto.setId(reward.getId());
        dto.setTitle(reward.getTitle());
        dto.setDescription(reward.getDescription());
        dto.setAmount(reward.getAmount());
        dto.setEstimatedDelivery(reward.getEstimatedDelivery());
        dto.setAvailableCount(reward.getAvailableCount());
        dto.setClaimedCount(reward.getClaimedCount());
        return dto;
    }
}