import { createContext, useState, useContext, useEffect } from 'react'

const AuthContext = createContext(null)

export const useAuth = () => useContext(AuthContext)

export const AuthProvider = ({ children }) => {
  const [currentUser, setCurrentUser] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    // Check if user is stored in localStorage
    const storedUser = localStorage.getItem('fundstartUser')
    if (storedUser) {
      setCurrentUser(JSON.parse(storedUser))
    }
    setLoading(false)
  }, [])

  // Login function
  const login = async (email, password) => {
    // In a real app, this would be an API call
    // For demo purposes, we'll simulate authentication
    
    if (email && password) {
      const user = {
        id: 'user123',
        name: 'Demo User',
        email,
        avatar: 'https://randomuser.me/api/portraits/women/44.jpg'
      }
      
      setCurrentUser(user)
      localStorage.setItem('fundstartUser', JSON.stringify(user))
      return user
    }
    
    throw new Error('Invalid credentials')
  }

  // Signup function
  const signup = async (name, email, password) => {
    // In a real app, this would be an API call
    // For demo purposes, we'll simulate registration
    
    if (name && email && password) {
      const user = {
        id: `user${Math.floor(Math.random() * 10000)}`,
        name,
        email,
        avatar: 'https://randomuser.me/api/portraits/men/32.jpg'
      }
      
      setCurrentUser(user)
      localStorage.setItem('fundstartUser', JSON.stringify(user))
      return user
    }
    
    throw new Error('Invalid information')
  }

  // Logout function
  const logout = () => {
    setCurrentUser(null)
    localStorage.removeItem('fundstartUser')
  }

  const value = {
    currentUser,
    login,
    signup,
    logout,
    loading
  }

  return (
    <AuthContext.Provider value={value}>
      {!loading && children}
    </AuthContext.Provider>
  )
}