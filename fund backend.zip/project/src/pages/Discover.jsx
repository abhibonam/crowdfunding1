import { useState, useEffect } from 'react'
import { FiSearch, FiFilter, FiX } from 'react-icons/fi'
import { motion, AnimatePresence } from 'framer-motion'
import { useProjects } from '../context/ProjectsContext'
import ProjectCard from '../components/projects/ProjectCard'
import CategoryButton from '../components/ui/CategoryButton'

export default function Discover() {
  const { projects, categories, loading } = useProjects()
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [searchTerm, setSearchTerm] = useState('')
  const [sortBy, setSortBy] = useState('trending')
  const [filteredProjects, setFilteredProjects] = useState([])
  const [isFilterOpen, setIsFilterOpen] = useState(false)

  // Filter projects based on category, search, and sort
  useEffect(() => {
    if (loading) return

    let result = [...projects]
    
    // Filter by category
    if (selectedCategory !== 'all') {
      result = result.filter(project => project.category === selectedCategory)
    }
    
    // Filter by search term
    if (searchTerm) {
      const lowerCaseSearch = searchTerm.toLowerCase()
      result = result.filter(project => 
        project.title.toLowerCase().includes(lowerCaseSearch) ||
        project.description.toLowerCase().includes(lowerCaseSearch) ||
        project.category.toLowerCase().includes(lowerCaseSearch)
      )
    }
    
    // Sort projects
    switch (sortBy) {
      case 'trending':
        // Sort by percentage funded (highest first)
        result.sort((a, b) => {
          const percentA = (a.funded / a.goal) * 100
          const percentB = (b.funded / b.goal) * 100
          return percentB - percentA
        })
        break
      case 'newest':
        // Sort by creation date (newest first)
        result.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt))
        break
      case 'endingSoon':
        // Sort by days left (fewest first)
        result.sort((a, b) => a.daysLeft - b.daysLeft)
        break
      case 'mostFunded':
        // Sort by total funding (highest first)
        result.sort((a, b) => b.funded - a.funded)
        break
      default:
        break
    }
    
    setFilteredProjects(result)
  }, [projects, selectedCategory, searchTerm, sortBy, loading])

  // Animation variants
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100
      }
    }
  }

  return (
    <div className="pt-24 pb-16">
      <div className="container">
        <h1 className="text-3xl md:text-4xl font-display font-bold mb-8">
          Discover Projects
        </h1>
        
        {/* Search and filters section */}
        <div className="mb-8 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="relative w-full md:w-96">
            <FiSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500" />
            <input
              type="text"
              placeholder="Search projects..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="input pl-10 w-full"
            />
            {searchTerm && (
              <button
                className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-500 hover:text-gray-700"
                onClick={() => setSearchTerm('')}
              >
                <FiX size={18} />
              </button>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <button
              className="md:hidden flex items-center text-gray-700 hover:text-primary-500"
              onClick={() => setIsFilterOpen(!isFilterOpen)}
            >
              <FiFilter className="mr-2" />
              Filters
            </button>
            
            <div className="hidden md:block">
              <label htmlFor="sort" className="mr-2 text-sm font-medium">
                Sort by:
              </label>
              <select
                id="sort"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="input py-2 w-40"
              >
                <option value="trending">Trending</option>
                <option value="newest">Newest</option>
                <option value="endingSoon">Ending Soon</option>
                <option value="mostFunded">Most Funded</option>
              </select>
            </div>
          </div>
        </div>
        
        {/* Mobile filters (slide down panel) */}
        <AnimatePresence>
          {isFilterOpen && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden overflow-hidden mb-6"
            >
              <div className="p-4 bg-gray-50 rounded-lg">
                <div className="mb-4">
                  <label htmlFor="mobile-sort" className="label">
                    Sort by:
                  </label>
                  <select
                    id="mobile-sort"
                    value={sortBy}
                    onChange={(e) => setSortBy(e.target.value)}
                    className="input w-full"
                  >
                    <option value="trending">Trending</option>
                    <option value="newest">Newest</option>
                    <option value="endingSoon">Ending Soon</option>
                    <option value="mostFunded">Most Funded</option>
                  </select>
                </div>
                
                <label className="label">Categories:</label>
                <div className="flex flex-wrap gap-2">
                  <CategoryButton
                    category="all"
                    label="All"
                    selected={selectedCategory === 'all'}
                    onClick={() => setSelectedCategory('all')}
                  />
                  {categories.map(category => (
                    <CategoryButton
                      key={category}
                      category={category}
                      label={category}
                      selected={selectedCategory === category}
                      onClick={() => setSelectedCategory(category)}
                    />
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
        
        {/* Desktop category filter */}
        <div className="hidden md:flex flex-wrap gap-3 mb-8">
          <CategoryButton
            category="all"
            label="All Projects"
            selected={selectedCategory === 'all'}
            onClick={() => setSelectedCategory('all')}
          />
          {categories.map(category => (
            <CategoryButton
              key={category}
              category={category}
              label={category}
              selected={selectedCategory === category}
              onClick={() => setSelectedCategory(category)}
            />
          ))}
        </div>
        
        {/* Results summary */}
        {!loading && (
          <p className="text-gray-600 mb-6">
            Showing {filteredProjects.length} {filteredProjects.length === 1 ? 'project' : 'projects'}
            {selectedCategory !== 'all' ? ` in ${selectedCategory}` : ''}
            {searchTerm ? ` matching "${searchTerm}"` : ''}
          </p>
        )}
        
        {/* Projects grid */}
        {loading ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, index) => (
              <div key={index} className="bg-gray-100 animate-pulse rounded-xl h-96"></div>
            ))}
          </div>
        ) : filteredProjects.length === 0 ? (
          <div className="py-16 text-center">
            <h3 className="text-xl font-display font-semibold mb-2">No projects found</h3>
            <p className="text-gray-600 mb-6">Try adjusting your search or filters</p>
            <button 
              onClick={() => {
                setSelectedCategory('all')
                setSearchTerm('')
                setSortBy('trending')
              }}
              className="btn btn-primary"
            >
              Reset filters
            </button>
          </div>
        ) : (
          <motion.div 
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
            variants={containerVariants}
            initial="hidden"
            animate="visible"
          >
            {filteredProjects.map(project => (
              <motion.div key={project.id} variants={itemVariants}>
                <ProjectCard project={project} />
              </motion.div>
            ))}
          </motion.div>
        )}
      </div>
    </div>
  )
}