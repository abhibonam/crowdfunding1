export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: {
          50: '#E6F7F8',
          100: '#CCEFF1',
          200: '#99DFE3',
          300: '#66CFD6',
          400: '#33BFC8',
          500: '#0CA5B0', // Primary color
          600: '#0A8A93',
          700: '#076F76',
          800: '#054F54',
          900: '#022A2D',
        },
        secondary: {
          50: '#F1EEFA',
          100: '#E3DDF5',
          200: '#C7B9EB',
          300: '#AB96E2',
          400: '#8F73D8',
          500: '#6B46C1', // Secondary color
          600: '#5A3BA1',
          700: '#482F80',
          800: '#37245F',
          900: '#25183F',
        },
        accent: {
          50: '#FFF4EF',
          100: '#FFE9DE',
          200: '#FFD3BD',
          300: '#FFBE9C',
          400: '#FFA87B',
          500: '#F97316', // Accent color
          600: '#CC5F12',
          700: '#A04B0E',
          800: '#753709',
          900: '#4A2305',
        },
        success: {
          500: '#10B981', // Success color
        },
        warning: {
          500: '#F59E0B', // Warning color
        },
        error: {
          500: '#EF4444', // Error color
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        display: ['Montserrat', 'sans-serif'],
      },
      spacing: {
        '128': '32rem',
        '144': '36rem',
      },
      borderRadius: {
        '4xl': '2rem',
      },
    },
  },
  plugins: [],
}