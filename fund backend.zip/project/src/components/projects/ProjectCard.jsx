import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'

export default function ProjectCard({ project }) {
  // Calculate percentage funded
  const percentFunded = Math.min(Math.round((project.funded / project.goal) * 100), 100)
  const isCompleted = percentFunded >= 100
  
  return (
    <Link to={`/projects/${project.id}`}>
      <motion.div 
        className="card group h-full flex flex-col"
        whileHover={{ y: -5 }}
      >
        <div className="relative aspect-video overflow-hidden">
          <img 
            src={project.imageUrl}
            alt={project.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
          />
          <div className="absolute bottom-0 left-0 right-0 px-4 py-2 bg-gradient-to-t from-black/80 to-transparent">
            <span className="text-xs font-medium text-white px-2 py-1 rounded bg-secondary-500">
              {project.category}
            </span>
          </div>
        </div>

        <div className="p-5 flex-grow flex flex-col">
          <h3 className="text-lg font-display font-semibold mb-2 line-clamp-2 group-hover:text-primary-500 transition-colors">
            {project.title}
          </h3>
          <p className="text-gray-600 text-sm mb-4 line-clamp-2">
            {project.description}
          </p>

          <div className="mt-auto">
            <div className="w-full bg-gray-200 h-2 rounded-full mb-2">
              <div 
                className={`h-2 rounded-full ${isCompleted ? 'bg-success-500' : 'bg-primary-500'}`}
                style={{ width: `${percentFunded}%` }}
              />
            </div>
            
            <div className="flex justify-between text-sm">
              <span className="font-medium">
                ${project.funded.toLocaleString()}
                <span className="text-gray-500 font-normal"> raised</span>
              </span>
              <span className={`font-medium ${isCompleted ? 'text-success-500' : ''}`}>
                {percentFunded}%
              </span>
            </div>
            
            <div className="flex justify-between mt-3 text-sm text-gray-600">
              <span>{project.backers} backers</span>
              <span>{project.daysLeft} days left</span>
            </div>
          </div>
        </div>
      </motion.div>
    </Link>
  )
}