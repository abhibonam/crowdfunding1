import { useState, useEffect } from 'react'
import { Routes, Route } from 'react-router-dom'
import { AnimatePresence } from 'framer-motion'

// Pages
import Home from './pages/Home'
import ProjectDetails from './pages/ProjectDetails'
import CreateProject from './pages/CreateProject'
import Discover from './pages/Discover'
import NotFound from './pages/NotFound'

// Components
import Header from './components/layout/Header'
import Footer from './components/layout/Footer'
import AuthModal from './components/auth/AuthModal'

// Context
import { AuthProvider } from './context/AuthContext'
import { ProjectsProvider } from './context/ProjectsContext'

function App() {
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false)
  const [authType, setAuthType] = useState('login') // 'login' or 'signup'
  
  const openAuthModal = (type) => {
    setAuthType(type)
    setIsAuthModalOpen(true)
  }

  const closeAuthModal = () => {
    setIsAuthModalOpen(false)
  }

  return (
    <AuthProvider>
      <ProjectsProvider>
        <div className="flex flex-col min-h-screen">
          <Header openAuthModal={openAuthModal} />
          <main className="flex-grow">
            <AnimatePresence mode="wait">
              <Routes>
                <Route path="/" element={<Home openAuthModal={openAuthModal} />} />
                <Route path="/projects/:id" element={<ProjectDetails openAuthModal={openAuthModal} />} />
                <Route path="/create" element={<CreateProject />} />
                <Route path="/discover" element={<Discover />} />
                <Route path="*" element={<NotFound />} />
              </Routes>
            </AnimatePresence>
          </main>
          <Footer />
          <AuthModal 
            isOpen={isAuthModalOpen} 
            onClose={closeAuthModal} 
            authType={authType}
            setAuthType={setAuthType}
          />
        </div>
      </ProjectsProvider>
    </AuthProvider>
  )
}

export default App